from zethg.core import EthiqueGarde

def test_veto():
    eg = EthiqueGarde()
    result = eg.veto("actionX")
    assert "Veto appliqué" in result
