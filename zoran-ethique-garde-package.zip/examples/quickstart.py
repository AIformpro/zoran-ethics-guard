from zethg.core import EthiqueGarde

eg = EthiqueGarde()
print(eg.veto("expérimentation non autorisée"))
