import yaml

class EthiqueGarde:
    def __init__(self, policy_file=None):
        self.policies = {}
        if policy_file:
            self.load_policies(policy_file)

    def load_policies(self, policy_file):
        with open(policy_file, 'r', encoding='utf-8') as f:
            self.policies = yaml.safe_load(f)

    def check_action(self, action):
        return self.policies.get(action, "Action non définie")

    def veto(self, action):
        return f"Veto appliqué sur : {action}"
